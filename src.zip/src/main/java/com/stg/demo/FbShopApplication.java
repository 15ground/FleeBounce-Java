package com.stg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FbShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(FbShopApplication.class, args);
	}

}
